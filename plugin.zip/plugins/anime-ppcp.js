import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command }) => {
	try {
		let res = await fetch(`https://api.akuari.my.id/randomimage/ppcouple`)
		let json = await res.json()
		let fimg = await fetch(json.hasil.cowok)
		let fimgb = Buffer.from(await fimg.arrayBuffer())
		if (Buffer.byteLength(fimgb) < 22000) throw new e()
		await conn.sendMessage(m.chat, { image: fimgb, caption: `Cowo` })
		await conn.sendMessage(m.chat, { image: { url: json.hasil.cewek }, caption: `Cewe` })
	} catch (e) {
		let res = await fetch(`https://api.lolhuman.xyz/api/random/ppcouple?apikey=AryaXyz`)
		if (!res.ok) return m.reply(`Error Kak`)
		let json = await res.json()
		await conn.sendMessage(m.chat, { image: { url: json.result.male }, caption: `Cowo` })
		await conn.sendMessage(m.chat, { image: { url: json.result.female }, caption: `Cewe` })
	}
}

handler.help = ['ppcouple']
handler.tags = ['searching']
handler.command = /^((pp)?couple|ppcp)$/i

handler.premium = false
handler.limit = true

export default handler